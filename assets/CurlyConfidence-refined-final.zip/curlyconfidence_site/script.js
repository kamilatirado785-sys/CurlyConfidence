/* CurlyConfidence — library + interactions */
const PROFESSIONAL_EMAIL = "kamilatirado02@gmail.com"; // Replace this one value before launch.

const library = [
  {id:"curl-types",cat:"curl-types",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Curl Types 101: 2A–4C",tag:"Curl Types",search:"2a 2b 2c 3a 3b 3c 4a 4b 4c wavy curly coily hair type",body:"Hair-pattern labels can be a useful visual language, but real hair can have several patterns at once. Use the photos as examples rather than rules.",bullets:["Look at your pattern when hair is clean and free of heavy styling products.","Different sections can have different patterns.","Texture, density, porosity, and strand thickness are also useful things to notice.","Your curl pattern does not determine what products you must use."]},
  {id:"porosity",cat:"care",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Porosity 101",tag:"Hair Care",search:"porosity low medium high moisture products dry hair",body:"Porosity describes how easily water and products move into and out of the hair strand. It can help explain why two people may respond differently to the same routine.",bullets:["Think about how quickly your hair becomes wet and dries.","Use your routine as evidence instead of relying on a single online porosity test.","Adjust product amount and layering based on how your hair responds.","Reassess over time because hair can change."]},
  {id:"detangling",cat:"care",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Gentle Detangling, Step by Step",tag:"Hair Care",search:"detangle knots comb brush kids curly coily natural hair",body:"Detangling can feel much easier when you slow down and work in sections. The goal is less pulling, not speed.",bullets:["Add slip with water and/or a conditioner that works for your hair.","Separate hair into manageable sections.","Start at the ends and work upward.","If a knot hurts, pause instead of forcing it.","Ask a child what feels comfortable and take breaks when needed."]},
  {id:"wash-day",cat:"wash",video:"https://www.youtube.com/watch?v=Z2qDW51kb04",videoId:"Z2qDW51kb04",source:"Jai Marii · YouTube",title:"Wash Day Basics",tag:"Wash Day",search:"wash day shampoo conditioner cleanse curls coily hair",body:"A simple wash day can be a repeatable routine rather than a complicated checklist.",bullets:["Gently cleanse the scalp and hair according to your routine.","Use conditioner to add slip before detangling.","Rinse thoroughly unless the product says otherwise.","Follow with the leave-in or styling steps that work for you.","Keep the routine flexible when someone is tired or in the hospital."]},
  {id:"hospital-routine",cat:"hospital",video:"https://www.youtube.com/watch?v=mbyjhzKeUuI",videoId:"mbyjhzKeUuI",source:"American Cancer Society · YouTube",title:"Keeping a Familiar Routine in the Hospital",tag:"Hospital",search:"hospital patient child caregiver routine hair care medical stay",body:"A familiar hair routine can be one small way to bring comfort and normalcy into a hospital stay. The routine should always fit the child’s current care plan and comfort.",bullets:["Ask the care team about any restrictions before haircare.","Bring familiar tools and products when permitted.","Keep supplies organized in one small bag.","Let the child choose between comfortable options when possible.","Stop if a step causes pain or discomfort and ask the care team for guidance."]},
  {id:"staff-conversations",cat:"hospital",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Haircare Conversations for Healthcare Staff",tag:"Hospital",search:"healthcare staff nurse doctor hospital communication textured hair child",body:"A respectful question can make haircare needs easier to understand without making assumptions about a child’s hair.",bullets:["Ask: “What does your normal hair routine look like at home?”","Ask what tools or products the family normally uses.","Ask whether there are cultural or family preferences the team should know.","Document relevant preferences according to your setting’s policies.","Do not assume a hairstyle or texture means a certain routine."]},
  {id:"kids-hair",cat:"kids",video:"https://www.youtube.com/watch?v=OJoyrA1FQ5Y",videoId:"OJoyrA1FQ5Y",source:"DiscoveringNatural · YouTube",title:"Haircare for Kids: You Get a Say",tag:"Kids & Caregivers",search:"kids children hair care confidence choice routine",body:"Haircare can be a learning experience. Children can participate by choosing comfortable tools, colors, styles, or the order of simple steps.",bullets:["Explain what you are about to do.","Give choices when there are safe options.","Use kid-friendly language instead of complicated hair terms.","Celebrate progress instead of perfect results."]},
  {id:"caregiver-kit",cat:"kids",video:"https://www.youtube.com/watch?v=OJoyrA1FQ5Y",videoId:"OJoyrA1FQ5Y",source:"DiscoveringNatural · YouTube",title:"Caregiver Haircare Bag Checklist",tag:"Kids & Caregivers",search:"caregiver bag hospital kit comb brush conditioner satin bonnet hair ties",body:"A small, organized haircare bag can make routines easier away from home.",bullets:["Wide-tooth comb or detangling brush used at home.","Familiar conditioner or leave-in product.","Soft hair ties or clips without rough edges.","Satin or smooth sleep protection if normally used.","Labels for the child’s belongings when required by the setting."]},
  {id:"moisture",cat:"care",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Moisture: What Does It Actually Mean?",tag:"Hair Care",search:"moisture hydration dry brittle curls conditioner leave in",body:"Moisture in haircare usually refers to keeping hair flexible and hydrated through water-based products and conditioning. Oils can help reduce friction or seal in moisture, but they are not the same thing as water.",bullets:["Water is a key part of hydration.","Conditioners can improve slip and softness.","Use oils based on how your hair responds, not because an ingredient is trending.","Too much product can create buildup, so balance matters."]},
  {id:"ingredients",cat:"ingredients",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Ingredients 101",tag:"Ingredients",search:"ingredients aloe glycerin shea butter protein oils shampoo conditioner product labels",body:"Learning ingredient names can make product labels less intimidating. No single ingredient is automatically perfect or bad for every person.",bullets:["Look at the full formula instead of judging one ingredient alone.","Humectants such as glycerin can attract water in many formulas.","Conditioning ingredients can help reduce friction and improve manageability.","Protein-containing products may feel helpful for some hair and too stiff for others.","Patch-test new products according to the product instructions."]},
  {id:"protein",cat:"ingredients",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Protein vs. Moisture",tag:"Ingredients",search:"protein moisture balance hair breakage strengthening curls",body:"Protein and conditioning/moisture-focused care can play different roles. The best balance depends on the hair and the formula.",bullets:["Protein-containing products can help some damaged or fragile hair feel stronger.","Too much of a strengthening-focused routine may make some hair feel stiff.","Conditioning products can improve softness and slip.","Change one variable at a time so you can tell what helped."]},
  {id:"styling",cat:"styling",video:"https://www.youtube.com/watch?v=SjV4fIAJ4vs",videoId:"SjV4fIAJ4vs",source:"Yinka Naturalista · YouTube",title:"Styling Techniques Library",tag:"Styling",search:"styling gel cream mousse twist braid wash go curls definition",body:"There are many ways to style curls, and you can choose the technique that feels manageable and comfortable.",bullets:["Apply products to damp or wet hair if that works for your routine.","Try scrunching, twisting, braiding, or section styling.","Use less tension around the hairline.","Give your hair time to dry before judging the final definition."]},
  {id:"refresh",cat:"styling",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"How to Refresh Curls",tag:"Styling",search:"refresh curls second day hair spray water leave in frizz",body:"A refresh can be simple. The goal is to revive the shape without starting a full wash day.",bullets:["Start with a small amount of water or your usual refresh product.","Focus on areas that need the most help.","Use gentle scrunching rather than rough rubbing.","Add more product only if needed."]},
  {id:"protective",cat:"styling",video:"https://www.youtube.com/watch?v=SjV4fIAJ4vs",videoId:"SjV4fIAJ4vs",source:"Yinka Naturalista · YouTube",title:"Low-Tension Protective Styles",tag:"Styling",search:"protective style braids twists low tension edges breakage",body:"Protective styling should protect the hair and scalp, not create pain or excessive tension.",bullets:["Choose a style that feels comfortable from the start.","Avoid tight pulling at the edges.","Give the scalp breaks between styles.","Keep the style clean and follow your normal wash routine."]},
  {id:"scalp",cat:"scalp",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Scalp Care Basics",tag:"Scalp",search:"scalp health flakes itching buildup shampoo clean scalp",body:"Scalp care is part of haircare. Gentle cleansing and paying attention to comfort can help you notice when something needs professional attention.",bullets:["Cleanse according to your routine and product instructions.","Avoid scratching hard or picking at the scalp.","Notice persistent pain, sores, or major changes and seek appropriate professional guidance.","Do not use medical treatments based only on an online hair guide."]},
  {id:"breakage",cat:"care",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Breakage, Shedding & Frizz",tag:"Hair Care",search:"breakage shedding frizz dryness tangles damage curls",body:"Some hair that comes out during detangling is normal shedding, while breakage is hair snapping along the strand. Frizz can also be a normal part of textured hair.",bullets:["Handle hair gently when wet and when dry.","Keep detangling tools clean and in good condition.","Reduce repeated high tension or rough manipulation.","If you notice sudden or concerning changes, ask a qualified professional."]},
  {id:"routine",cat:"care",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",source:"American Academy of Dermatology · YouTube",title:"Build a Simple Curl Routine",tag:"Hair Care",search:"routine beginner curly hair steps simple weekly daily",body:"A good routine is one you can repeat. Start small and add steps only when you know why you want them.",bullets:["Cleanse when your scalp and routine call for it.","Condition and detangle with enough slip.","Choose one styling step that meets your goal.","Protect hair at night if that is part of your normal routine.","Track what works instead of changing everything at once."]},
  {id:"video-detangle",cat:"kids",title:"Video: Curly Hair Detangling for Kids",tag:"Video",search:"youtube video detangle curly hair kids wash routine",video:"https://www.youtube.com/watch?v=b083Ryor9Cs",videoId:"b083Ryor9Cs",body:"A kid-focused demonstration of a wash-day and detangling routine. Review outside content before sharing it with children.",source:"SIMPLY LOCS · YouTube"},
  {id:"video-aad",cat:"care",title:"Video: 6 Curly Hair Tips From Dermatologists",tag:"Video · Dermatology",search:"youtube curly hair dermatologist breakage moisture detangle scalp",video:"https://www.youtube.com/watch?v=HdKBtlvamfs",videoId:"HdKBtlvamfs",body:"A short educational video from the American Academy of Dermatology covering curly/coily hair care, moisture, detangling, scalp care, sun protection, and sleep protection.",source:"American Academy of Dermatology · YouTube"},
  {id:"video-wavy",cat:"curl-types",title:"Video: Wavy Hair Routine 2A/2B/2C",tag:"Video · 2A–2C",search:"youtube 2a 2b 2c wavy hair routine",video:"https://www.youtube.com/watch?v=b8_uol3GS1Y",videoId:"b8_uol3GS1Y",body:"A visual routine for wavy hair patterns 2A, 2B, and 2C. Use it as an example, not a rule for what every wavy-haired person must do.",source:"Suhanna De Silva · YouTube"},
  {id:"video-curly",cat:"curl-types",title:"Video: Understanding 3A/3B/3C Curl Types",tag:"Video · 3A–3C",search:"youtube 3a 3b 3c curly hair types",video:"https://www.youtube.com/watch?v=SWMytQlhVSg",videoId:"SWMytQlhVSg",body:"A visual comparison of 3A, 3B, and 3C curl patterns. Curl labels are only a starting point because one head of hair can contain more than one pattern.",source:"frfootball · YouTube"},
  {id:"video-coily",cat:"styling",title:"Video: Natural Hairstyles for 4A, 4B & 4C",tag:"Video · 4A–4C",search:"youtube 4a 4b 4c natural hair styles black african american hair",video:"https://www.youtube.com/watch?v=L2UY-VFlJns",videoId:"L2UY-VFlJns",body:"A style-focused video featuring 4A, 4B, and 4C natural hair. It can be a starting point for exploring styles and representation across coily textures.",source:"BeautyInNatural · YouTube"},
  {id:"video-length",cat:"care",title:"Video: Length Retention for 4A/4B/4C",tag:"Video · Coily Hair",search:"youtube 4a 4b 4c length retention breakage natural hair",video:"https://www.youtube.com/watch?v=tZuzFGjM2wQ",videoId:"tZuzFGjM2wQ",body:"A creator-led discussion of length retention for 4A, 4B, and 4C hair, including habits the creator has used in their own routine.",source:"Janet Davies · YouTube"},
  {id:"video-4c",cat:"styling",title:"Video: 4C Wash-Day Routine",tag:"Video · 4C",search:"youtube 4c wash day natural hair",video:"https://www.youtube.com/watch?v=mvY5H8utJVk",videoId:"mvY5H8utJVk",body:"An external creator video focused on a 4C wash-day routine. It is not CurlyConfidence clinical guidance.",source:"Jenn Jackson · YouTube"},
  {id:"black-hair-care",cat:"care",title:"Black & African American Hair Care",tag:"Black / African American Hair",search:"black african american natural hair coily kinky textured hair moisture breakage protective styles 4a 4b 4c",body:"Black and African American hair includes many textures, styles, densities, and routines. This guide brings together practical education on moisture, gentle handling, detangling, protective styling, and breakage prevention without assuming one routine fits everyone.",bullets:["Natural hair can be wavy, curly, coily, or a combination of patterns.","Protective styles should feel comfortable and should not create excessive tension.","Moisture, conditioning, and gentle detangling can help manage dryness and breakage.","Children may need extra time, choices, and breaks during haircare.","Use professional guidance for persistent scalp symptoms, sudden hair loss, or other concerning changes."],video:"https://www.youtube.com/watch?v=SjV4fIAJ4vs",videoId:"SjV4fIAJ4vs",source:"Yinka Naturalista · YouTube"},
  {id:"kids-detangling",cat:"kids",title:"How to Detangle a Child’s Hair Without Making It a Struggle",tag:"Kids & Caregivers",search:"child kids daughter son detangle knots curly coily natural hair tears gentle brush comb",body:"Children deserve a hair routine that is gentle, predictable, and respectful. Work in sections, use enough slip, and let the child participate in choices that are safe.",bullets:["Explain the next step before you start.","Use water and/or conditioner for slip when appropriate for your routine.","Start at the ends and move upward in small sections.","Pause for breaks if the child is uncomfortable or tired.","Avoid forcing through painful knots."],video:"https://www.youtube.com/watch?v=OJoyrA1FQ5Y",videoId:"OJoyrA1FQ5Y",source:"DiscoveringNatural · YouTube"}
];

const curlData = {
  "2a": {title:"2A — Loose Waves", text:"Soft, subtle waves with a relaxed pattern. Hair may look straighter near the roots and more wavy toward the ends.", img:"assets/curl-2a.jpg"},
  "2b": {title:"2B — Wavy", text:"More defined waves with a bit more volume. Different sections can still behave differently.", img:"assets/curl-2b.jpg"},
  "2c": {title:"2C — Deep Waves", text:"Well-defined waves that start to form a curl. Hair may have more texture and volume.", img:"assets/curl-2c.jpg"},
  "3a": {title:"3A — Loose Curls", text:"Big, springy curls with an S-shaped pattern. Curl size can vary across the head.", img:"assets/curl-3a.jpg"},
  "3b": {title:"3B — Springy Curls", text:"More defined, springy curls with a smaller curl shape and noticeable volume.", img:"assets/curl-3b.jpg"},
  "3c": {title:"3C — Tight Curls", text:"Very tight curls with lots of density. Gentle detangling and moisture-focused care may be helpful.", img:"assets/curl-3c.jpg"},
  "4a": {title:"4A — Defined Coils", text:"Soft, tight coils that can form a visible S pattern. Shrinkage and density can vary.", img:"assets/curl-4a.jpg"},
  "4b": {title:"4B — Z-Shaped Coils", text:"Tighter coils with a less defined pattern. Hair may have significant shrinkage.", img:"assets/curl-4b.jpg"},
  "4c": {title:"4C — Tightest Coils", text:"Very tight coils or zig-zag patterns with significant shrinkage. Gentle, sectioned care can make routines more manageable.", img:"assets/curl-4c.jpg"}
};

const quizQuestions = [
  {title:"What does your hair look like?",help:"Choose what feels closest — or pick “I’m not sure.”",options:[["wavy","Mostly loose waves"],["curly","Curls or ringlets"],["coily","Very tight curls or coils"],["unsure","I’m not sure"]]},
  {title:"What do you want help with most?",help:"Pick the goal that would make your routine easier.",options:[["detangle","Detangling"],["moisture","Keeping hair moisturized"],["wash","Washing and cleansing"],["routine","Building a simple routine"]]},
  {title:"How do you usually care for your hair?",help:"There is no right or wrong answer.",options:[["daily","A little every day"],["weekly","About once a week"],["sometimes","Whenever I have time"],["help","I need help figuring it out"]]},
  {title:"Who are these resources for?",help:"Choose the option that fits your situation.",options:[["kid","Me / a child"],["caregiver","A caregiver"],["staff","Healthcare staff"],["everyone","Everyone"]]},
  {title:"How confident do you feel?",help:"Choose the answer that feels closest.",options:[["confident","I feel pretty confident"],["learning","I’m still learning"],["support","I want more support"],["unsure","I’m not sure where to start"]]}
];

let quizIndex=0, quizAnswers={};
let activeFilter="all";

const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

function openModal(id){document.getElementById(id).classList.add("open");document.body.style.overflow="hidden"}
function closeModal(id){document.getElementById(id).classList.remove("open");document.body.style.overflow=""}
$$(".modal-close").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
$$(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal(m.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")$$(".modal.open").forEach(m=>closeModal(m.id))});

function renderLibrary(){
  const q=$("#resourceSearch").value.trim().toLowerCase();
  const results=library.filter(item=>{
    const filterOk=activeFilter==="all" || (activeFilter==="videos" && item.video) || (activeFilter==="black-hair" && (item.id==="black-hair" || /black|african american|natural hair|coily|4a|4b|4c/i.test(item.search))) || item.cat===activeFilter;
    const searchText=`${item.title} ${item.tag} ${item.search} ${item.body}`.toLowerCase();
    return filterOk&&(!q||searchText.includes(q));
  });
  $("#resultCount").textContent=`${results.length} resource${results.length===1?"":"s"}`;
  $("#noResults").classList.toggle("hidden",results.length!==0);
  $("#resourceGrid").innerHTML=results.map(item=>`
    <article class="resource-card">
      <div class="resource-image">${item.img?`<img src="${item.img}" alt="">`:"<span>CURLYCONFIDENCE GUIDE</span>"}</div>
      <span class="tag">${item.tag}</span>
      <h3>${item.title}</h3>
      <p>${item.body.slice(0,135)}${item.body.length>135?"…":""}</p>
      <button class="text-button library-open" data-id="${item.id}" type="button">${item.video?"Read + Watch →":"Read Full Guide →"}</button>
    </article>`).join("");
  $$(".library-open").forEach(b=>b.addEventListener("click",()=>openResource(b.dataset.id)));

  more?.classList.toggle("hidden", visible.length>=filtered.length);
}
function openResource(id){
  const item=library.find(x=>x.id===id); if(!item)return;
  const video=item.video?`<div class="video-lesson"><div class="video-heading"><span class="eyebrow">WATCH & LEARN</span><h3>Short YouTube lesson</h3></div><div class="video-frame"><iframe src="https://www.youtube-nocookie.com/embed/${item.videoId}" title="${item.title} video" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div><p><a class="button primary" href="${item.video}" target="_blank" rel="noopener noreferrer">Open on YouTube ↗</a></p></div>`:"";
  const source=item.source?`<p class="source-note">Video credit: ${item.source}. CurlyConfidence curates this external lesson and does not own it.</p>`:"<p class=\"source-note\">CurlyConfidence educational guide. Review and adapt information for your family, setting, and care needs.</p>";
  $("#contentModalBody").innerHTML=`
    <p class="eyebrow">${item.tag.toUpperCase()}</p>
    <h2 id="contentModalTitle">${item.title}</h2>
    <div class="guide-meta"><span>CurlyConfidence Library</span><span>Searchable guide</span></div>
    <p>${item.body}</p>
    <ul class="guide-list">${item.bullets.map(x=>`<li>${x}</li>`).join("")}</ul>
    ${video}${source}`;
  openModal("contentModal");
}

$("#resourceSearch").addEventListener("input",renderLibrary);
$$(".filter-chip").forEach(btn=>btn.addEventListener("click",()=>{
  activeFilter=btn.dataset.filter;
  $$(".filter-chip").forEach(x=>x.classList.toggle("active",x===btn));
  renderLibrary();
}));
$("#heroSearch").addEventListener("keydown",e=>{
  if(e.key==="Enter"){e.preventDefault();$("#resourceSearch").value=e.currentTarget.value;activeFilter="all";$$(".filter-chip").forEach(x=>x.classList.toggle("active",x.dataset.filter==="all"));document.querySelector("#resources").scrollIntoView({behavior:"smooth"});renderLibrary();}
});

function openCurl(type){
  if(type==="all"){document.querySelector("#resources").scrollIntoView({behavior:"smooth"});$("#resourceSearch").value="curl";renderLibrary();return}
  const c=curlData[type];if(!c)return;
  $("#hairGuide").innerHTML=`<div class="guide-curl"><img src="${c.img}" alt="${c.title} example"><div><span class="eyebrow">CURL PATTERN EXAMPLE</span><h3>${c.title}</h3><p>${c.text}</p><p class="source-note">Image credit: CurlyConfidence-generated visual. No people are shown.</p></div></div>`;
  $("#hairGuide").classList.remove("hidden");$("#hairGuide").scrollIntoView({behavior:"smooth",block:"center"});
}
$$(".hair-card").forEach(c=>c.addEventListener("click",()=>openCurl(c.dataset.type)));
$$(".type-chip").forEach(b=>b.addEventListener("click",()=>openCurl(b.dataset.type)));

function renderQuiz(){
  const q=quizQuestions[quizIndex],pct=((quizIndex+1)/quizQuestions.length)*100;
  $("#quizContent").innerHTML=`<div class="quiz-question"><span class="eyebrow">QUESTION ${quizIndex+1} OF ${quizQuestions.length}</span><div class="progress"><i style="width:${pct}%"></i></div><h2 id="quizModalTitle">${q.title}</h2><p>${q.help}</p>${q.options.map(([v,l])=>`<button class="quiz-option" data-value="${v}" type="button">${l}</button>`).join("")}</div>`;
  $$(".quiz-option").forEach(b=>b.addEventListener("click",()=>{quizAnswers[quizIndex]=b.dataset.value;if(quizIndex<quizQuestions.length-1){quizIndex++;renderQuiz()}else renderQuizResult()}));
}
function renderQuizResult(){
  const pattern=quizAnswers[0],goal=quizAnswers[1];
  const map={wavy:"2A–2C",curly:"3A–3C",coily:"4A–4C",unsure:"any curl pattern"};
  const goalMap={detangle:"Gentle Detangling",moisture:"Moisture 101",wash:"Wash Day Basics",routine:"Build a Simple Curl Routine"};
  const search=goalMap[goal]||"curl";
  $("#quizContent").innerHTML=`<div class="quiz-result"><p class="eyebrow">YOUR STARTING POINT</p><h2 id="quizModalTitle">${map[pattern]||"Your curl journey"}</h2><p>You can start with our <strong>${goalMap[goal]||"beginner guides"}</strong> resources. Remember: curl-pattern labels are only a starting point.</p><div class="button-row"><button class="button primary" id="quizResources" type="button">Open My Resources</button><button class="button secondary" id="quizAgain" type="button">Retake Quiz</button></div></div>`;
  $("#quizResources").addEventListener("click",()=>{closeModal("quizModal");$("#resourceSearch").value=search;activeFilter="all";$$(".filter-chip").forEach(x=>x.classList.toggle("active",x.dataset.filter==="all"));document.querySelector("#resources").scrollIntoView({behavior:"smooth"});renderLibrary()});
  $("#quizAgain").addEventListener("click",()=>{quizIndex=0;quizAnswers={};renderQuiz()});
}
$("#quizStart").addEventListener("click",()=>{quizIndex=0;quizAnswers={};openModal("quizModal");renderQuiz()});

$$(".role-card").forEach(c=>c.addEventListener("click",()=>{
  const target=c.dataset.target==="kids"?"#resources":"#resources";
  $(target).scrollIntoView({behavior:"smooth"});
  if(c.dataset.target==="kids"){$("#resourceSearch").value="kids";renderLibrary()}
  if(c.dataset.target==="caregiver"){$("#resourceSearch").value="caregiver";renderLibrary()}
  if(c.dataset.target==="staff"){$("#resourceSearch").value="healthcare";renderLibrary()}
}));

$("#contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  if(!PROFESSIONAL_EMAIL || PROFESSIONAL_EMAIL.includes("YOUR-PROFESSIONAL")){alert("Add your professional CurlyConfidence email in script.js first.");return}
  const f=new FormData(e.currentTarget);
  const subject=encodeURIComponent(`CurlyConfidence inquiry: ${f.get("interest")}`);
  const body=encodeURIComponent(`Name: ${f.get("name")}\nEmail: ${f.get("email")}\nInterest: ${f.get("interest")}\n\n${f.get("message")}`);
  window.location.href=`mailto:${PROFESSIONAL_EMAIL}?subject=${subject}&body=${body}`;
});
$("#professionalEmail").textContent=PROFESSIONAL_EMAIL;
$("#donateButton").addEventListener("click",()=>{$("#interestSelect").value="Donation / Sponsorship";});
const menuToggle=$(".menu-toggle"),nav=$(".nav");
menuToggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuToggle.setAttribute("aria-expanded",String(open))});
$$(".nav a").forEach(link=>link.addEventListener("click",()=>{$$(".nav a").forEach(a=>a.classList.remove("active"));link.classList.add("active");nav.classList.remove("open")}));

const videoLibrary=library.filter(item=>item.videoId);
let videoFilter="all";
let videoShown=6;
function renderVideoLibrary(){
  const grid=$("#videoGrid"), more=$("#videoMore");
  if(!grid)return;
  const list=videoLibrary.filter(item=>videoFilter==="all" || item.cat===videoFilter);
  const visible=list.slice(0,videoShown);
  grid.innerHTML=visible.map(item=>`
    <article class="video-card">
      <a class="video-thumb" href="${item.video}" target="_blank" rel="noopener noreferrer" aria-label="Watch ${item.title} on YouTube">
        <img src="https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg" alt="YouTube thumbnail for ${item.title}" loading="lazy">
        <span class="play-badge">▶</span>
      </a>
      <div class="video-card-body">
        <span class="tag">${item.tag}</span>
        <h3>${item.title}</h3>
        <p>${item.body}</p>
        <a class="button primary" href="${item.video}" target="_blank" rel="noopener noreferrer">Watch on YouTube ↗</a>
        <div class="video-credit">Credit: ${item.source||"Original creator · YouTube"}</div>
      </div>
    </article>`).join("");
  more?.classList.toggle("hidden", visible.length>=list.length);
}
$$('[data-video-filter]').forEach(btn=>btn.addEventListener('click',()=>{
  $$('[data-video-filter]').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
  videoFilter=btn.dataset.videoFilter; videoShown=6; 
$("#resourceMore")?.addEventListener("click",()=>{resourceShown+=8;renderLibrary();});
renderVideoLibrary();
}));
$("#videoMore")?.addEventListener("click",()=>{videoShown+=6;renderVideoLibrary();});

renderVideoLibrary();
renderLibrary();
