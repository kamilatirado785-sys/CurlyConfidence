# CurlyConfidence Website

This version keeps the original CurlyConfidence layout and adds a larger searchable education library without changing the overall look and feel.

## What was added
- Expanded searchable Resource Library with a growing set of hair-care topics and learning sets.
- Instant search across titles, categories, keywords, and guide text.
- Category filters for curl types, care, wash day, styling, ingredients, scalp, kids/caregivers, and hospital resources.
- Full guide modals with practical, beginner-friendly information plus embedded, credited YouTube lessons where available.
- Visual curl examples for 2A–4C.
- Generated curl visuals contain no people and are labeled as educational examples.
- Photo-credit labels are included so every image has a clear source/credit.
- New support/donation area that routes visitors to the contact form until a secure donation platform is connected.
- Professional-email display and mailto form wiring.
- Existing quiz, navigation, role cards, bilingual toggle button area, contact section, and overall pastel layout are preserved.

## IMPORTANT: add your professional email
Open `script.js` and change:

`const PROFESSIONAL_EMAIL = "YOUR-PROFESSIONAL-EMAIL-HERE";`

to the public email you want people to use, for example your real school/project/professional address.

The email is intentionally not invented or hard-coded because you have not provided the address yet.

## Photos and credits
The current curl-pattern images are AI-generated educational visuals made for CurlyConfidence and do not contain people. They are not presented as photographs of a real person.

If you later replace any generated image with a real photograph, keep the credit directly under that image (photographer/creator + source link or license information).

## Donation setup
The Donate / Sponsor button currently opens the contact section and selects "Donation / Sponsorship." This avoids inventing a payment link. When you choose a secure donation provider, replace that button with the provider's official donation URL.

## Launch checklist
1. Add your professional email in `script.js`.
2. Review the educational content with a trusted adult/qualified professional before publishing.
3. Replace or expand the generated curl visuals if you obtain properly licensed real photographs.
4. Add your secure donation link when ready.
5. Replace external YouTube resources with your own reviewed videos if desired.
6. Deploy the folder to GitHub Pages, Netlify, Cloudflare Pages, or another static host.

This is a plain HTML/CSS/JavaScript site with no build step.


## Video Learning Library
The site now includes a curated YouTube learning section covering kids' detangling, dermatologist-backed curly-hair care, 2A–2C waves, 3A–3C curls, 4A–4C coily hair, length retention, and 4C wash day. Videos are linked to the original YouTube pages and credited to their creators/organizations. YouTube video metadata and thumbnails are loaded from YouTube when the page is viewed.

The library also connects major search topics to a three-part learning path: **short explanation → CurlyConfidence guide/article → credited YouTube lesson**.

## Original logo
The original `assets/logo.png` from the earlier functional CurlyConfidence package is retained in this final build.

## GitHub update
Replace the contents of your current GitHub website folder with the contents of this ZIP. Keep the folder structure exactly as provided so `index.html`, `styles.css`, `script.js`, and `assets/` stay together. Do not delete `assets/logo.png`.
